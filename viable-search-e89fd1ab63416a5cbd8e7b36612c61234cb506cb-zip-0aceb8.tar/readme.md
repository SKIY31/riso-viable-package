#viable/search


This package allow API to **select fields**, **filtering**, **sort** and **return selected relations**

**Let's do this!**

**Apply Search to your model!**

    class Post extends Eloquent {
      use SearchTrait;
    }

**Filter your API!**

    class PostsController extends Controller {
      public function index() {
        return Post::filter()->get();
      }
    }

**What data do you need?**

> I need title and id of posts in a thread with ID 42...

> ...that contain a string "awesome"...

> ...that are no older than March 2017...

> ...that have been posted by any user other than the one with ID 666.

> One more thing... sort it so that I get active posts at the top...

> Oh, and make active and inactive posts sorted by the date they were posted...

> Did I mention I need the user data with every post?

    GET /api/v1/posts
      ?fields=id,title
      &thread_id=42
      &text=%awesome%
      &created_at=(ge)201703
      &user_id=!666
      &sort=-is_active,-created_at
      &with=user

**Done! That's It**

## Overview

Laravel 5 package that allows to dynamically select fields, filter, sort and eager load relations for your models using request parameters.

It combines the following Traits:

- [Selectable](#selectable) - select fields
- [Searchable](#sortable) - filter models
- [Sortable](https://bitbucket.org/viablelabs/vlsearch-api/src/a8662e8c8f0a16c28d843843d832650472a1ef0b/src/SortableTrait.php?at=master&fileviewer=file-view-default) - sort models
- [Withable](https://bitbucket.org/viablelabs/vlsearch-api/src/a8662e8c8f0a16c28d843843d832650472a1ef0b/src/WithableTrait.php?at=master&fileviewer=file-view-default) - eager load relations

It simplifies embedding them in your models and allows using all 4 of them with a single function call.


## Install

Via Composer

Include package in require for composer.json

``` 
"viable/search": "dev-master"
```

## Usage

### Search your model
In order to apply all functionality to your model class, you need to import **SearchTrait** into your model. This will internally import all 4 behaviours.

    use Viable\Search\SearchTrait;
    
    class Model extends Eloquent {
      use SearchTrait;
    }

By default all model fields are selectable, searchable and sortable; all relations can be eagerly loaded by default as well.
If you need to limit which fields can model be selected, filtered and sorted by and which relations can be loaded, see documentation
of corresponding behaviour Trait.

### Search your API

Once you apply Search Trait to your model, additional method **filter()** will be available on the model that enables the additional behaviour.
All criteria will be taken from the request automatically, but if you want to override the request parameters, you can
pass the desired value to the **filter()** method:

    //override all parameters
    return Model::filter($selectColumns ,$filters, $sort, $relations)->get();

    //override sorting criteria only
    return Model::filter(null, null, $sort)->get();

Information how to configure the behaviours using request parameters can be found in documentation of corresponding behaviour Trait.

### Additional configuration

If you are using `fields` request parameter for other purpose, you can change the name of the parameter that will be
 interpreted as selecting criteria by setting a `$selectParameterName` property in your model, e.g.:

     protected $selectParameterName = 'selectFields';

 If you are using `sort` request parameter for other purpose, you can change the name of the parameter that will be
 interpreted as sorting criteria by setting a `$sortParameterName` property in your model, e.g.:

     protected $sortParameterName = 'sortBy';

 If you are using `with` request parameter for other purpose, you can change the name of the parameter that will be
  interpreted as a list of relations to load by setting a `$withParameterName` property in your model, e.g.:

     protected $withParameterName = 'relations';


#Selectable

## Selecting fields

```php
// return all posts with fields id, name and created_at
Post::filter(['id, name, created_at'], null, null, null)->get();

```
or it will use `fields` parameter from the request as default:

```php   
// return all posts with fields id, name and created_at by appending to URL
?fields=id,name,created_at
//and then calling
Post::filter()->get();
```
## Additional configuration

 If you are using `fields` request parameter for other purpose, you can change the name of the parameter that will be
 interpreted as selecting criteria by setting a `$selectParameterName` property in your model, e.g.:
```php
 protected $selectParameterName = 'selectColumns';
```

#sortable

## Setting up sortable models

You can either define a `$sortable` property or implement a `getSortableAttributes` method if you want to execute some logic to define
list of sortable fields.

```php
use Viable\Search\SearchTrait;

class Post extends Eloquent
{
    use SearchTrait;

    // either a property holding a list of sortable fields...
    public $sortable = ['title', 'forum_id', 'created_at'];

    // ...or a method that returns a list of sortable fields
    public function getSortableAttributes()
    {
        return ['title', 'forum_id', 'created_at'];
    }
}
```
In order to make all fields sortable put an asterisk `*` in the list of sortable fields:

```php
public $sortable = ['*'];
```

## Sorting models

`SortableTrait` adds a `sorted()` scope to the model - you can pass it a query being an array of sorting conditions:

```php
// return all posts sorted by creation date in descending order
Post::filter(null, '+created_at')->get();

// return all users sorted by level in ascending order and then by points indescending orders
User::filter(null, '+level,-points')->get();
```
or it will use `sort` parameter from the request as default:

```php   
// return all posts sorted by creation date in descending order by appending to URL
?sort=-created_at
//and then calling
Post::filter()->get();

// return all users sorted by level in ascending order and then by points indescending orders by appending to URL
?sort=+level,-points
// and then calling
User::filter()->get();
```
## Defining default sorting criteria

It is possible to define default sorting criteria that will be used if no sorting criteria are provided in the request or
passed to `sorted` method of your model. Default sorting criteria should be defined in $defaultSortCriteria property, e.g.:

```php
// sort by latest first
protected $defaultSortCriteria = ['-created_at'];
```

## Defining default sorting order

By default asc is considered as default sorting order. It is possible to define default sorting order that will be used if no sorting order is provided in the request or
passed to `sorted` method of your model. Default sorting order should be defined in $defaultSortOrder property, e.g.:

```php
// sort in desc order by default if no order is specified in request
protected $defaultSortOrder = 'desc';
// sort in asc order by default if no order is specified in request
protected $defaultSortOrder = 'asc';
```

#Searchable


## Setting up searchable models

You can either define a $searchable property or implement a getSearchableAttributes method if you want to execute some logic to define list of searchable fields.

    use Viable\Search\SearchTrait;
    
    class Post extends Eloquent
    {
        use SearchTrait;

        // either a property holding a list of searchable fields...
        public $searchable = ['title', 'forum_id', 'user_id', 'created_at'];

        // ...or a method that returns a list of searchable fields
        public function getSearchableAttributes()
        {
            return ['title', 'forum_id', 'user_id', 'created_at'];
        }
    }

In order to make all fields searchable put an asterisk * in the list of searchable fields:

    public $searchable = ['*'];

It is also possible to blacklist model's attributes to prevent it from being filtered on.

You can either define a $notSearchable property or implement a getNotSearchableAttributes method if you want to execute some logic to define list of searchable fields.

    use Viable\Search\SearchTrait;

    class Post extends Eloquent
    {
        use SearchTrait;

        // either a property holding a list of not searchable fields...
        public $notSearchable = ['created_at'];

        // ...or a method that returns a list of not searchable fields
        public function getNotSearchableAttributes()
        {
            return ['created_at'];
        }
    }

If you define both lists - searchable and not searchable columns - the resulting set of searchable fields will contain
all whitelisted attributes except all blacklisted attributes.

## Searching models

You can pass it a query being an array of filter conditions:
 
    // return all posts with forum_id equal to $forum_id
    Post::filter(null, null, ['forum_id' => $forum_id])->get();
    
    // return all posts with with <operator> applied to forum_id
    Post::filter(null, null, ['forum_id' => <operator>])->get();
 
 or it will use `Input::all()` as default:
    
    // if you append ?forum_id=<operator> to the URL, you'll get all Posts with <operator> applied to forum_id
    Post::filter()->get();

## Choosing query mode
The default query mode is to apply conjunction (```AND```) of all queries to searchable model. It can be changed to disjunction (```OR```)
by setting value of `mode` query paramter to `or`. If the `mode` query parameter is already in use, name returned by `getQueryMode` method
will be used.
 
## Building a query

The `SearchableTrait` supports the following operators:
    
### Comparison operators
Comparison operators allow filtering based on result of comparison of model's attribute and query value. They work for strings, numbers and dates. They have the following for:
    
    (<operator>)<value>

The following comparison operators are available:

* `gt` for `greater than` comparison
* `ge` for `greater than or equal` comparison
* `lt` for `less than` comparison, e.g
* `le` for `les than or equal` comparison
* `btwn` for `between` 

In order to filter posts from 2015 and newer, the following query should be used:

    ?created_at=(ge)2015-01-01
    
### Equals/In operators
Searchable trait allows filtering by exact value of an attribute or by a set of values, depending on the type of value passed as query parameter. 
If the value contains commas, the parameter is split on commas and used as array input for `IN` filtering, otherwise exact match is applied.
    
In order to filter posts from user with id 42, the following query should be used:

    ?user_id=42
    
In order to filter posts from forums with id 7 or 8, the following query should be used:

    ?forum_id=7,8
    
### Like operators
Like operators allow filtering using `LIKE` query. This operator is triggered if exact match operator is used, but value contains `%` sign as first or last character.

In order to filter posts that start with `How`, the following query should be used:

    ?title=How%

```Notice:``` percentage character is used to encode special characters in URLs, so when sending the request make sure the tools
you use properly ```encode the % character as %25```
    
### Negation operator
It is possible to get negated results of a query by prepending the operator with `!`.
    
Some examples:
    
    //filter posts from all forums except those with id 7 or 8
    ?forum_id=!7,8
    
    //filter posts older than 2015
    ?created_at=!(ge)2015

### Between operator
It is possible to get values between some specific range 

some example:

    //filter amount between 10 to 30
    ?filter=(btwn)10,30

### Multiple constraints for single attribute
It is possible to apply multiple constraints for a single model's attribute. 
In order to achieve that provide an array of query filters instead of a single filter:

    // filter all posts from year 20** except 2013
    ?created_at[]=20%&created_at[]=!2013%

## Filtering by relation attributes
It is possible to filter by attributes of model's relations - Eloquent's ```whereHas()``` will be applied. In order to filter
by relation, add the relation attribute to the list of ```searchable``` fields in the form ```relation:attribute```. The same string
should be used in the query to filter by that relation's attribute, e.g.:

     // allow filtering on user's active field
     protected $searchable = ['user:active'];
 
     // filter only posts of active users
     ?user:active=1

#Withable

## Setting up withable models

You can either define a `$withable` property or implement a `getWithableRelations` method if you want to execute some logic to define
list loadable relations.

    use Viable\Search\SearchTrait;
    
    class Post extends Eloquent
    {
        use SearchTrait;

        // either a property holding a list of loadable relations...
        protected $withable = ['owner', 'forum'];

        // ...or a method that returns a list of loadable relations
        protected function getWithableRelations()
        {
            return ['owner', 'forum'];
        }
    }

In order to make all relations loadable put an asterisk `*` in the list:

    protected $withable = ['*'];

## Loading relations

    // return all posts with the user who created them and forum where they were posted
    Post::filter(null, null, null, ['owner', 'forum'])->get();
    // return all posts with the user who created them
    Post::filter(null, null, null, 'owner')->get();

 or it will use `Input::all()` as default. In the URL you can pass a list of relations to load or a single relation in the `with` parameter:
    
    // return all posts with the user who created them and forum where they were posted by appending to the URL
    ?with[]=owner&with[]=forum
    // return all posts with the user who created them
     ?with=owner
     //and then calling
    Post::filter()->get();

##Select specific fields from relations 
    // return all posts with the user who create and for user only name is required
     ?with[]=owner:id,name
     
__note__: if you select specific fields you must need to include foreign key value, in above case post and owner are related with owner_id(posts) and id(owner), so while selecting field for owner, it is required to include id, otherwise it will return blank result for relation.

## Additional configuration

If you are using `with` request parameter for other purpose, you can change the name of the parameter that will be
 interpreted as a list of relations to load by setting a `$withParameterName` property in your model, e.g.:

    protected $withParameterName = 'relations';

If you need to execute additional logic to define a list of relations to load (e.g. permission checking),
you can implement `getWithRelationsList()` method in your model and make that return list of relations:

    public function getWithRelationsList() {
      return Input::get('relations');
    }