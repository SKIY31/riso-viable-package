<?php namespace Viable\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Input;
use RuntimeException;

trait SelectableTrait
{

    /**
     * Exclude an array of elements from the result.
     * @param $query
     * @param $columns
     * @return mixed
     */
    public function scopeFields(Builder $builder, $query)
    {
        $query = ($query ?: Input::input($this->_getSelectParameterName(), $this->_getDefaultSelectableCriteria()));

        if (empty($query)) {
            $query = $this->_getSelectableAttributes($builder);
        }

        if ($query) {

            if (!is_array($query))
                $query = explode(',', $query);


            return $builder->select($query);
        } else {
            return $builder;
        }

    }

    protected function _getDefaultSelectableCriteria()
    {
        return isset($this->defaultSelectableCriteria) ? $this->defaultSelectableCriteria : [];
    }

    protected function _getSelectParameterName()
    {
        return isset($this->selectParameterName) ? $this->selectParameterName : 'fields';
    }

    /**
     * @param Builder $builder
     *
     * @return array list of selectable attributes
     */
    protected function _getSelectableAttributes(Builder $builder)
    {
        if (method_exists($builder->getModel(), 'getSelectableAttributes')) {
            return $builder->getModel()->getSelectableAttributes();
        }

        if (property_exists($builder->getModel(), 'selectable')) {
            return $builder->getModel()->selectable;
        }

        throw new RuntimeException(sprintf('Model %s must either implement getSelectableAttributes() or have $selectable property set', get_class($builder->getModel())));
    }

}
