<?php namespace Viable\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Input;
use RuntimeException;

trait WithableTrait
{

    /**
     * Add eager loaded relations.
     *
     * @param Builder $builder query builder
     * @param array $relations list of relations to be loaded
     */
    public function scopeWithRelations(Builder $builder, $relations = null)
    {
        $with = [];
        foreach ($this->getWithRelationsList($relations) as $relation) {

            $relationAndColumns = explode(":", $relation);
            $relation = $relationAndColumns[0];

            $columns = '*';
            if (!empty($relationAndColumns[1])) {
                $columns = explode(',', $relationAndColumns[1]);
            }

            if ($this->isWithableRelation($builder, $relation)) {
                $builder->with([$relation => function ($query) use ($columns) {
                    $query->select($columns);
                }]);
            }
        }

    }

    protected function isWithableRelation(Builder $builder, $relation)
    {
        $withable = $this->_getWithableRelations($builder);

        return in_array($relation, $withable) || in_array('*', $withable);
    }

    protected function getWithRelationsList($relations = null)
    {
        return $relations ? (array)$relations : (array)Input::get($this->_getWithParameterName(), []);
    }

    /**
     * @return array list of relations that can be eagerly loaded
     */
    protected function _getWithableRelations(Builder $builder)
    {
        if (method_exists($builder->getModel(), 'getWithableRelations')) {
            return $builder->getModel()->getWithableRelations();
        }

        if (property_exists($builder->getModel(), 'withable')) {
            return $builder->getModel()->withable;
        }

        throw new RuntimeException(sprintf('Model %s must either implement getWithableRelations() or have $withable property set', get_class($builder->getModel())));
    }

    protected function _getWithParameterName()
    {
        return isset($this->withParameterName) ? $this->withParameterName : 'with';
    }
}
