<?php namespace Viable\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Input;

trait SearchTrait
{
    use SortableTrait;

    use WithableTrait;

    use SelectableTrait;

    use SearchableTrait;

    protected function getSearchableAttributes()
    {
        return property_exists($this, 'searchable') ? $this->searchable : ['*'];
    }

    protected function getSortableAttributes()
    {
        return property_exists($this, 'sortable') ? $this->sortable : ['*'];
    }

    protected function getWithableRelations()
    {
        return property_exists($this, 'withable') ? $this->withable : ['*'];
    }

    protected function getSelectableAttributes()
    {
        return property_exists($this, 'selectable') ? $this->selectable : ['*'];
    }

    /**
     * Enable searchable, sortable and withable scopes
     *
     * @param Builder $builder query builder
     * @param array $query¡¡
     */
    public function scopeFilter(Builder $builder, $select = [], $query = [], $sort = [], $relations = [])
    {
        $this->attributes['sortParameterName'] = $this->_getSortParameterName();
        $this->attributes['selectParameterName'] = $this->_getSelectParameterName();
        $this->attributes['withParameterName'] = $this->_getWithParameterName();

        $query = $query ?: array_except(Input::all(), [$this->sortParameterName, $this->withParameterName, $this->selectParameterName]);

        $builder->fields($select)->filtered($query)->sorted($sort)->withRelations($relations);
    }
}
