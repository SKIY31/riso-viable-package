<?php
/**
 * Created by PhpStorm.
 * User: anandpatel
 * Date: 29/09/17
 * Time: 10:44 AM
 */

Route::get('feedback', function () {
    echo 'Viable Feedback routes';
});