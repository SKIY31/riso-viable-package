# Viable/feedback

## Install

Via Composer

Include package in require for composer.json

``` 
"viable/feedback": "dev-master"
```

As this is private package we need to set source to the private repository. 
you can define source in `composer.json` by adding `repositories` key with git URL

(Note: Please make sure you have access to the repository and your ssh is added to bitbucket)

``` 
 "repositories": [
        {
            "type": "vcs",
            "url":  "ssh://git@bitbucket.org/viablelabs/vlfeedback-api.git"
        }
 ]
```

add the service provider in `config/app.php` :

```
Viable\Feedback\FeedbackServiceProvider::class
```