<?php

Route::group(['namespace' => 'Viable\Feedback\Controllers'], function () {
    Route::post(config('feedback.uri', '/api/feedbacks'), [
        'uses' => 'FeedbackController@store'
    ]);
});
