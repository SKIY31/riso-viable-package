<?php

namespace Viable\Feedback\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Viable\Feedback\FeedbackEntity;

class StoredFeedbackMailToDeveloper extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * FeedbackEntity instance.
     *
     * @var FeedbackEntity
     */
    public $feedback;

    /**
     * Create a new message instance.
     *
     * @param  FeedbackEntity $feedback
     */
    public function __construct(FeedbackEntity $feedback)
    {
        $this->feedback = $feedback;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->markdown('feedback::to-administrator')
            ->to(config('feedback.administrator.address'), config('feedback.administrator.name'))
            ->subject("【{$this->feedback->id}】" . config('feedback.mail_subject'));
    }
}
