<?php

namespace Viable\Feedback\Controllers;

use Viable\Feedback\FeedbackEntity;
use Viable\Feedback\Mail\StoredFeedbackMailToDeveloper;
use Viable\Feedback\Requests\StoreFeedbackRequest;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Http\JsonResponse;

class FeedbackController extends Controller
{
    /**
     * @var Mailer
     */
    protected $mailer;

    /**
     * Create a new controller instance.
     *
     * @param  Mailer $mailer
     */
    public function __construct(Mailer $mailer)
    {
        $this->middleware(config('feedback.middleware', 'api'));

        $this->mailer = $mailer;
    }

    /**
     * Store a feedback.
     *
     * @param  StoreFeedbackRequest $request
     * @return JsonResponse
     */
    public function store(StoreFeedbackRequest $request)
    {

        $data = $request->only(['name', 'email', 'message']);

        $feedback = FeedbackEntity::create($data);

        if (config('feedback.mail_to_administrator', false)) {
            $this->mailer->send(new StoredFeedbackMailToDeveloper($feedback));
        }

        return response()->json(["message" => config('feedback.success_message', "Feedback saved successfully!"), "data" => compact('feedback')], 201);
    }
}
