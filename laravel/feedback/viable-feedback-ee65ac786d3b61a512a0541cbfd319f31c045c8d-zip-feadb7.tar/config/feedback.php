<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Feedback config.
    |--------------------------------------------------------------------------
    */

    // Feedbacks table name
    'table' => 'feedbacks',

    // API URI
    'uri' => '/api/feedbacks',

    // Feedback validation rule
    'rule' => [
        'message' => 'required|string|min:5|max:1000',
        'email' => 'required|email',
        'name' => 'required'
    ],

    // Feedback controller middleware
    'middleware' => 'api',

    // Whether to email administrator
    'mail_to_administrator' => true,

    // Mail subject (to dev)
    'mail_subject' => 'Received a feedback',

    // administrator info
    'administrator' => [

        'address' => env('FEEDBACK_TO_EMAIL', ''),

        'name' => env('FEEDBACK_TO_NAME', ''),

    ],

    "success_message" => "Feedback save successfully!"
];
