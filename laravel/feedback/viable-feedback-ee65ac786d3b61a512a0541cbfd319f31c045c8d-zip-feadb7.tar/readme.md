# Viable/feedback

This package provide feedback API to your Laravel project and send feedback to administrator 

## Install

Via Composer

Include package in require for composer.json

``` 
"viable/feedback": "dev-master"
```

As this is private package for Viable we need to set source to the private repositories. 
you can define source in `composer.json` by adding repositories key with URL

``` 
 {
   "repositories": [{
     "type": "composer",
     "url": "https://satis.viable.is"
   }]
 }
```

include the service provider within `config/app.php` in `providers`  

```
'providers' => [
    Viable\Feedback\FeedbackServiceProvider::class,
];
```

You can customize setting and email template

```
$ php artisan vendor:publish --provider="Viable\Feedback\FeedbackServiceProvider"
```

After that you can find `feedback.php` in `config` directory and `to-administrator.blade.php` in `resources/views/vendor/feedback/` directory

For creating a table, you need fire migration command

`php artisan migrate`

##Usage


Route is located at: 

`Post: /api/feedbacks`

Request parameters: 

```
{
    "email" : "anand.patel1991@gmail.com",
    "name" : "Anand Patel",
    "message" : "Awesome feedback!"  
}
```

Success Response with code 201: 

```
{
    "message": "Feedback save successfully!",
    "data": {
        "feedback": {
            "name": "anand patel",
            "email": "anand.patel@gmail.com",
            "message": "Awesome Feedback!",
            "updated_at": "2017-10-12 12:29:05",
            "created_at": "2017-10-12 12:29:05",
            "id": 7
        }
    }
}
```

Failed Response with code 422: 

```
{
    "errors": {
        "email": [
            "The email field is required."
        ]
    }
}
```

