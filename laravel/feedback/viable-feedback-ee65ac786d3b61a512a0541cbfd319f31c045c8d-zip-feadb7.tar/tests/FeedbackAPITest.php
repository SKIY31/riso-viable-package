<?php

namespace Viable\Feedback\Tests;

use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Viable\Feedback\Mail\StoredFeedbackMailToDeveloper;
use Illuminate\Support\Facades\Mail;

class FeedbackAPITest extends TestCase
{
    use DatabaseTransactions;

    /**
     * @test
     */
    public function it_stores_feedback()
    {
        Mail::fake();
        $message = 'This is a feedback message.';
        $email = 'hello@viable.is';
        $name = 'Viable Feedback';

        $this->postJson('/api/feedbacks', compact('name', 'email', 'message'))
            ->assertStatus(201)
            ->assertJsonStructure(['data'])
            ->assertJsonFragment(compact('name', 'email', 'message'));
        $this->assertDatabaseHas(config('feedback.table'), compact('name', 'email', 'message'));
        Mail::assertNotSent(StoredFeedbackMailToDeveloper::class);
    }

    /**
     * @test
     */
    public function it_posting_message_less_than_five_characters()
    {
        $message = str_random(3);
        $email = 'hello@viable.is';
        $name = 'Viable Feedback';
        $this->postJson('/api/feedbacks', compact('name', 'email', 'message'))
            ->assertStatus(422)
            ->assertJsonStructure(['errors']);
        $this->assertDatabaseMissing('feedbacks', compact('message'));
    }

    public function email_is_required()
    {
        $message = "Viable feedback";
        $email = null;
        $name = 'Viable Feedback';
        $this->postJson('/api/feedbacks', compact('name', 'email', 'message'))
            ->assertStatus(422)
            ->assertJsonStructure(['errors']);
        $this->assertDatabaseMissing('feedbacks', compact('message'));
    }
}