<?php

namespace Viable\Authentication;

use Illuminate\Support\ServiceProvider;
use Viable\Authentication\Commands\AuthenticationCommand;

class AuthenticationServiceProvider extends ServiceProvider
{
    /**
     * Register bindings in the container.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadRoutesFrom(__DIR__.'/routes/routes.php');
        $this->loadMigrationsFrom(__DIR__.'/migrations');
        $this->commands(
            [
                AuthenticationCommand::class,
            ]
        );
    }
}