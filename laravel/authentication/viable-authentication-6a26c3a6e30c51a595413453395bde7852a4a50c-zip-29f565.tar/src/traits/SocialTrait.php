<?php

namespace Viable\Authentication\Traits;

use App\Models\User;
use App\Repositories\UserRepository;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Viable\Authentication\Models\UserSocialToken;

trait SocialTrait
{
    /**
     * Driver used for social login
     *
     * @var string $driver
     */
    protected $driver;
    /**
     * Default password for social users that don't have a local account
     *
     * @var string $socialDefaultPass
     */
    private $socialDefaultPass = '__NOT_SET';

    /**
     * Social login redirect for local app
     *
     * @param string $driver
     *
     * @return mixed
     */
    public function redirectToProvider(string $driver)
    {
        $this->setDriver($driver);

        return Socialite::driver($this->getDriver())->redirect();
    }

    /**
     * @return string
     */
    public function getDriver()
    {
        return $this->driver;
    }

    /**
     * @param string $driver
     */
    public function setDriver(string $driver)
    {
        $services = include base_path('config/services.php');

        if (!$services[$driver]) {
            throw new BadRequestHttpException(
                "Please add your credentials before attempting to use this driver!"
            );
        }

        $this->driver = $driver;

    }

    /**
     * Social login callback for local app
     *
     * @param string $driver
     *
     * @return User
     */
    public function handleProviderCallback(string $driver)
    {
        $this->setDriver($driver);
        $user = Socialite::driver($this->getDriver())->user();
        $user = $this->updateOrCreateUser($user);

        Auth::login($user);

        return redirect($this->redirectTo);
    }

    /**
     * @param $socialUser
     *
     * @return mixed
     */
    public function updateOrCreateUser($socialUser)
    {
        $user = User::where('email', $socialUser->email)->first();

        if (empty($socialUser->email)) {
            throw new BadRequestHttpException(
                "User email not provided. The social login system used did not provide a valid email."
            );
        }

        if (empty($user)) {

            $userData = [
                'email'    => $socialUser->email,
                'password' => $this->socialDefaultPass,
                'name'     => $socialUser->name,
            ];

            if (method_exists(User::class, 'socialExtraUserFields')) {
                foreach (User::socialExtraUserFields() as $key => $value) {
                    $userData[$key] = $value;
                }
            }

            $user = User::create($userData);
            $user->profile()->updateOrCreate(
                [
                    'avatar' => $socialUser->avatar,
                ]
            );
        }

        return $user;
    }

    /**
     * Retrieves user from social app and returns api token
     *
     * @param string $token
     * @param string $driver
     *
     * @return mixed
     * @throws AuthorizationException
     */
    public function loginFromExternal(string $driver, string $token)
    {
        $this->setDriver($driver);
        try {
            $user = Socialite::driver($this->getDriver())->with(['prettyPrint' => true])
                ->userFromToken($token);
        } catch (\Exception $exception) {
            $errors = $exception->getMessage();
            $messagePos = strpos($errors, 'message');
            $errors = substr(
                $errors,
                $messagePos,
                (strpos($errors, 'locationType') - $messagePos - 3)
            );
            throw new BadRequestHttpException($errors);
        }

        if ($user) {
            $user = $this->updateOrCreateUser($user);
            if ($driver == 'facebook') {
                $this->getAndStoreLongLiveTokenFacebook($token, $user);
            }

            $apiToken = $user->createToken('Created From Social Login');

            return $apiToken;
        } else {
            throw new AuthorizationException("Social token is invalid!");
        }
    }

    /**
     * @param string $slt
     * @param User   $user
     */
    public function getAndStoreLongLiveTokenFacebook(string $slt, User $user)
    {
        $tokens = UserSocialToken::where('user_id', $user->id)->where(
            'driver',
            'facebook'
        )
            ->whereNotNull('long_live_token')->get();

        if ($tokens->isEmpty()) {
            $token = file_get_contents(
                'https://graph.facebook.com/oauth/access_token?grant_type=fb_exchange_token&client_id='
                .env('FACEBOOK_CLIENT_ID').'&client_secret='.env('FACEBOOK_SECRET')
                .'&fb_exchange_token='.$slt
            );

            $user->socialToken()->updateOrCreate(
                [
                    'driver'           => 'facebook',
                    'short_live_token' => $slt,
                    'long_live_token'  => json_decode($token, true)['access_token'],
                ]
            );
        }
    }
}