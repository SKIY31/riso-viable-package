<?php

namespace Viable\Authentication\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $user_id
 * @property string $first_name
 * @property string $last_name
 * @property string $avatar
 * @property string $locale
 * @property string $birthday
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 */
class UserProfile extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['user_id', 'first_name', 'last_name', 'avatar', 'locale', 'birthday', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }
}
