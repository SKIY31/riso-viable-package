<?php

namespace Viable\Authentication\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $user_id
 * @property string $driver
 * @property string $short_live_token
 * @property string $long_live_token
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 */
class UserSocialToken extends Model
{
    /**
     * @var array
     */
    protected $fillable
        = [
            'user_id',
            'driver',
            'short_live_token',
            'long_live_token',
            'created_at',
            'updated_at',
        ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }
}
