<?php

namespace Viable\Authentication\Commands;

use Illuminate\Console\Command;

class AuthenticationCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'viable:authentication:make';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Install the full authentication service in a project.';

    /**
     * Users Model path
     *
     * @var $userModelPath
     */
    protected $userModelPath;

    /**
     * Create a new command instance.
     *
     * SendEmails constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->userModelPath = base_path('app/Models/User.php');
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Calling Auth:Make');
        $this->call('make:auth');

        $this->info('Rolling migrations');
        $this->call('migrate');

        $this->info('Calling Passport:install');
        $this->call('passport:install');

        $this->copyUserModelIfNotInModelsFolder();

        $this->addRelationsToUserModel();

        $this->addHasApiTokensTraitToUserModel();

        $this->addPassportRoutesToAuthServiceProvider();

        $this->changeAuthConfigToPassportAndModel();

        $this->addSocialTraitToLoginController();

        $this->changeUserModelInRegisterController();

        $this->info('Everything is set. Please follow the readme instructions now');

    }

    /**
     * Copies the User model in the Models folder if its not already there
     */
    private function copyUserModelIfNotInModelsFolder()
    {
        if (!file_exists($this->userModelPath)) {
            if (file_exists(base_path('app/User.php'))) {
                if (!file_exists(base_path('app/Models'))) {
                    mkdir(base_path('app/Models'), 0777, true);
                }
                copy(base_path('app/User.php'), $this->userModelPath);

                $fname = $this->userModelPath;

                $fHandle = fopen($fname, 'r');
                $content = fread($fHandle, filesize($fname));

                $newContent = str_replace(
                    'namespace App;',
                    'namespace App\Models;',
                    $content
                );
                file_put_contents($fname, $newContent);
            }
        }
    }

    /**
     * Appends the UserProfile and UserSocialToken relations to the user model
     *
     * @return bool
     */
    private function addRelationsToUserModel()
    {
        $fname = $this->userModelPath;
        $content = file_get_contents($fname);
        if (strpos($content, 'public function profile()')) {
            return true;
        }
        $content = rtrim($content, PHP_EOL);
        $content = rtrim($content, '}');

        $relations
            = '
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function profile()
    {
        return $this->hasOne("Viable\Authentication\Models\UserProfile");
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function socialToken()
    {
        return $this->hasOne("Viable\Authentication\Models\UserSocialToken");
    }

}
            ';

        $content .= $relations;
        file_put_contents($fname, $content);
    }

    /**
     * Appends the HasApiToken trait to the User model
     *
     * @return bool
     */
    private function addHasApiTokensTraitToUserModel()
    {
        $fname = $this->userModelPath;
        $content = file_get_contents($fname);

        if (strpos($content, 'use Laravel\Passport\HasApiTokens;')) {
            return true;
        }

        $newContent = str_replace(
            'use Notifiable;',
            'use Notifiable, HasApiTokens;',
            $content
        );
        $newContent = str_replace(
            'use Illuminate\Notifications\Notifiable;',
            'use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;',
            $newContent
        );

        file_put_contents($fname, $newContent);
    }

    /**
     * Appends the Passport::routes() method to the AuthServiceProvider
     *
     * @return bool
     */
    private function addPassportRoutesToAuthServiceProvider()
    {

        $fname = 'app/Providers/AuthServiceProvider.php';
        $content = file_get_contents($fname);

        if (strpos($content, 'use Laravel\Passport\Passport;')) {
            return true;
        }

        $content = str_replace(
            '$this->registerPolicies();',
            '$this->registerPolicies();
        Passport::routes();',
            $content
        );
        $content = str_replace(
            'use Illuminate\Support\Facades\Gate;',
            'use Illuminate\Support\Facades\Gate;
use Laravel\Passport\Passport;',
            $content
        );

        file_put_contents($fname, $content);
    }

    /**
     * Switch api driver to passport and use the App\Models\User model
     *
     * @return bool
     */
    private function changeAuthConfigToPassportAndModel()
    {
        $fname = 'config/auth.php';
        $content = file_get_contents($fname);

        if (strpos($content, "'driver' => 'passport',")) {
            return true;
        }

        $content = str_replace(
            "'driver' => 'token',",
            "'driver' => 'passport',",
            $content
        );
        $content = str_replace(
            "'model' => App\User::class,",
            "'model' => App\Models\User::class,",
            $content
        );

        file_put_contents($fname, $content);
    }

    /**
     * Adds the SocialTrait to the Login Controller
     *
     * @return bool
     */
    private function addSocialTraitToLoginController()
    {
        $fname = 'app/Http/Controllers/Auth/LoginController.php';
        $content = file_get_contents($fname);

        if (strpos($content, 'use Viable\Authentication\Traits\SocialTrait;')) {
            return true;
        }

        $content = str_replace(
            'use App\Http\Controllers\Controller;',
            'use App\Http\Controllers\Controller;
use Viable\Authentication\Traits\SocialTrait;',
            $content
        );
        $content = str_replace(
            'use AuthenticatesUsers;',
            'use AuthenticatesUsers, SocialTrait;',
            $content
        );

        file_put_contents($fname, $content);
    }

    /**
     * Changes the Model used in RegisterController from App\User to App\Models\User
     *
     * @return bool
     */
    private function changeUserModelInRegisterController()
    {
        $fname = 'app/Http/Controllers/Auth/RegisterController.php';
        $content = file_get_contents($fname);

        if (strpos($content, 'App\Models\User')) {
            return true;
        }

        $content = str_replace('App\User', 'App\Models\User', $content);

        file_put_contents($fname, $content);
    }
}