<?php
Route::group(
    ['middleware' => ['web']],
    function () {
        Route::get(
            'login/{driver}',
            'App\Http\Controllers\Auth\LoginController@redirectToProvider'
        );
        Route::get(
            'login/{driver}/callback',
            'App\Http\Controllers\Auth\LoginController@handleProviderCallback'
        );
    }
);

Route::get(
    'login/{driver}/external/{token}',
    'App\Http\Controllers\Auth\LoginController@loginFromExternal'
);