# VLAuthentication-API reusable module

Authentication module wraps Laravel's Auth, Passport and Socialite modules together, in a ready to use module.

For a local app, the social login works with the following route: 'login/{driver}'. Simply add the social login button that redirects to this route.
If the login is successful, a user is created (if not existent by email), and logged-in in site.

For the api social login, the route used is: 'login/{driver}/external/{token}' where {token} is the user_token provided by the
social platform. If the login is successful, a user is created (if not existent by email) and a api-token is returned.

The package uses the users model located in App\Models\User. If the Model is not there, it will copy it from App, and add the necessary components.
If app\User is not used at all, it can be deleted.

Install:

Add the following in your composer.json file:

"repositories": [{
    "type": "composer",
    "url": "https://satis.viable.is"
}]

and in require, add: "viable/authentication": "dev-master"

Steps after installation: 

1. Call php artisan viable:authentication:make
 
2. Add the drivers in the services.php config in the following form:
    'facebook' => 
        [
            'client_id'     => env('FACEBOOK_CLIENT_ID'),
            'client_secret' => env('FACEBOOK_SECRET'),
            'redirect'      => env('APP_URL')."/login/facebook/callback",
        ]
