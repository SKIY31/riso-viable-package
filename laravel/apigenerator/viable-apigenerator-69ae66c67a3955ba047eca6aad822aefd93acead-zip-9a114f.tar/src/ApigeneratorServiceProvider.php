<?php

namespace Viable\Apigenerator;

use Illuminate\Support\ServiceProvider;

class ApigeneratorServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->registerModelCommand();
        $this->registerControllerRestActionsCommand();
        $this->registerControllerCommand();
        $this->registerRouteCommand();
        $this->registerMigrationCommand();
        $this->registerResourceCommand();
        $this->registerPivotTableCommand();
        $this->registerFactoryCommand();
        $this->registerSeederCommand();
        $this->registerResourcesCommand();

    }

    protected function registerModelCommand(){
        $this->app->singleton('command.generate.model', function($app){
            return $app['Viable\Apigenerator\Console\ModelCommand'];
        });
        $this->commands('command.generate.model');
    }

    protected function registerControllerRestActionsCommand(){
        $this->app->singleton('command.generate.controller.rest-actions', function($app){
            return $app['Viable\Apigenerator\Console\ControllerRestActionsCommand'];
        });
        $this->commands('command.generate.controller.rest-actions');
    }

    protected function registerControllerCommand(){
        $this->app->singleton('command.generate.controller', function($app){
            return $app['Viable\Apigenerator\Console\ControllerCommand'];
        });
        $this->commands('command.generate.controller');
    }

    protected function registerMigrationCommand(){
        $this->app->singleton('command.generate.migration', function($app){
            return $app['Viable\Apigenerator\Console\MigrationCommand'];
        });
        $this->commands('command.generate.migration');
    }

    protected function registerRouteCommand(){
        $this->app->singleton('command.generate.route', function($app){
            return $app['Viable\Apigenerator\Console\RouteCommand'];
        });
        $this->commands('command.generate.route');
    }

    protected function registerTestCommand(){
        $this->app->singleton('command.generate.test', function($app){
            return $app['Viable\Apigenerator\Console\TestCommand'];
        });
        $this->commands('command.generate.test');
    }

    protected function registerResourceCommand(){
        $this->app->singleton('command.generate.resource', function($app){
            return $app['Viable\Apigenerator\Console\ResourceCommand'];
        });
        $this->commands('command.generate.resource');
    }

    protected function registerResourcesCommand(){
        $this->app->singleton('command.generate.resources', function($app){
            return $app['Viable\Apigenerator\Console\ResourcesCommand'];
        });
        $this->commands('command.generate.resources');
    }

    protected function registerPivotTableCommand(){
        $this->app->singleton('command.generate.pivot-table', function($app){
            return $app['Viable\Apigenerator\Console\PivotTableCommand'];
        });
        $this->commands('command.generate.pivot-table');
    }

    protected function registerFactoryCommand(){
        $this->app->singleton('command.generate.factory', function($app){
            return $app['Viable\Apigenerator\Console\FactoryCommand'];
        });
        $this->commands('command.generate.factory');
    }

    protected function registerSeederCommand(){
        $this->app->singleton('command.generate.seeder', function($app){
            return $app['Viable\Apigenerator\Console\SeederCommand'];
        });
        $this->commands('command.generate.seeder');
    }

    protected function registerPivotSeederCommand(){
        $this->app->singleton('command.generate.pivot.seeder', function($app){
            return $app['Viable\Apigenerator\Console\PivotSeederCommand'];
        });
        $this->commands('command.generate.pivot.seeder');
    }
}