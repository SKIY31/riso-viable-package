<?php namespace Viable\Apigenerator\Exceptions;


class TemplateException extends \Exception {}
