<?php namespace Viable\Apigenerator\Exceptions;


class ArgumentFormatException extends \Exception {}
