<?php namespace Viable\Apigenerator\Exceptions;


class ArgumentParserException extends \Exception {}
