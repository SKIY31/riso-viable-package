<?php namespace Viable\Apigenerator\Console;

/**
 * Class ResourceV2Command
 *
 * @package Viable\Apigenerator\Console
 */
class ResourceV2Command extends BaseCommand
{
    CONST TYPE_REPOSITORY = "Repository";
    CONST TYPE_SERVICE = "Service";

    /**
     * How is the command called from console
     *
     * @var string
     */
    protected $signature = "generate:resource_v2";

    /**
     * Commands description
     *
     * @var string
     */
    protected $description = "Generates resources: Model, Repository, Service, Request Validator and Controllers";

    /**
     * Command that executes when called
     */
    public function handle()
    {
        $name = ucwords($this->ask('What is the name of the resource ?'));

        if (file_exists(base_path('config/api_generator.php'))) {
            $paths = include base_path('/config/api_generator.php');
        } else {
            $paths = include base_path('/vendor/viable/apigenerator/src/paths.php');
        }

        $this->checkForDirectoryStructure($paths);
        $this->checkForTraits($paths);
        $this->call(
            'krlove:generate:model',
            [
                'class-name'    => $name,
                '--output-path' => $paths['models'],
                '--namespace'   => 'App\Models',
            ]
        );

        $repository = fopen(
            $paths['repositories'].'/'.$name.self::TYPE_REPOSITORY.'.php',
            'w'
        );
        $this->writeInFile(
            $repository,
            $name,
            $paths['repositories'],
            self::TYPE_REPOSITORY
        );
        $service = fopen($paths['services'].'/'.$name.self::TYPE_SERVICE.'.php', 'w');
        $this->writeInFile($service, $name, $paths['services'], self::TYPE_SERVICE);

        $this->call('make:request', ['name' => $name.'Request']);

        if (!file_exists(base_path('app/Traits/RESTActions.php'))) {
            $this->call('generate:controller:rest-actions');
        }

        $this->call(
            'generate:controller',
            ['model' => $name, 'path' => $paths['api'], '--no-routes' => true]);
    }

    /**
     * Creates the base structure of directories
     *
     * @param $paths
     */
    protected function checkForDirectoryStructure($paths)
    {
        foreach ($paths as $key => $path) {
            if (!file_exists($path)) {
                mkdir($path);
            }
        }
    }

    /**
     * Chcecks if the basic traits exist and creates them if not
     *
     * @param $paths
     */
    protected function checkForTraits($paths)
    {
        $traits = [
            'api'     => 'ApiTrait.php',
            'repo'    => 'RepositoryTrait.php',
            'service' => 'ServiceTrait.php',
        ];

        foreach ($traits as $key => $trait) {
            if (!file_exists($paths['traits'].$trait)) {
                $content = $this->getTemplate('traits/'.$key)->get();
                $this->save($content, "./app/Traits/".$trait, $trait);
            }
        }
    }

    /**
     * Writes generated files
     *
     * @param $file
     * @param $name
     */
    protected function writeInFile($file, $name, $path, $type)
    {
        $text['namespace'] = $this->fromPathToNamespace($path)."\n";
        $text['use'] = "use App\Traits\\".$type."Trait; \n";
        if ($type == self::TYPE_REPOSITORY) {
            $text['use_2'] = "use App\Models\\".$name."; \n";
        }
        $text['class'] = "\nclass ".$name.$type." \n{ \n";
        $text['uses'] = "\tuse ".$type."Trait;\n\n";
        if ($type == self::TYPE_REPOSITORY) {
            $text['setConsruct_name'] = "\tpublic function __construct()\n\t{\n";
            $text['setConstruct_content'] = "\t\t\$this->setModel();\n";
            $text['setConstruct_close'] = "\t}\n\n";
            $text['setModel_name'] = "\tpublic function setModel() \n\t{\n";
            $text['setModel_content'] = "\t\t\$this->model = new ".$name."();\n";
            $text['setModel_close'] = "\t}";
        }
        $text['closeBrackets'] = "\n}\n";

        foreach ($text as $item) {
            fwrite($file, $item);
        }

        fclose($file);

    }

    /**
     * @param $path
     *
     * @return string
     */
    protected function fromPathToNamespace($path)
    {
        $namespace = substr($path, strpos($path, 'app'));
        $namespace = str_replace("/", "\\", $namespace);

        return "<?php namespace ".ucfirst($namespace)."; \n";
    }
}