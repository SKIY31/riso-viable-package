<?php namespace Viable\Apigenerator\Console;


class RouteCommand extends BaseCommand {

	protected $signature = 'generate:route
		{resource : Name of the resource.}
        {--controller= : Name of the REST Api controller.}
        {--restversion= : Version - default V1 }
        {--methods= : methods for resource rest api.}
    ';

	protected $description = 'Generates REST Api routes.';

    public function handle()
    {
        $resource = $this->argument('resource');
        $version = ($this->option('restversion'))? strtolower($this->option('restversion')):'v1';

        $routesPath = app_path("routes/api-{$version}.php");
        if (! $this->fs->exists($routesPath)){
            $content = $this->getTemplate('route/routes-version')
                ->with([
                    'version' => $version,
                ])
                ->get();
            $this->save($content, $routesPath, "{$resource} routes", true);
        }

        $content = $this->fs->get($routesPath);

        if (! $this->option('methods')){
            $addition = PHP_EOL . $this->getTemplate('route/routes')
                    ->with([
                        'resource' => str_plural($resource),
                        'version' => strtoupper($version),
                        'controller' => $this->getController()
                    ])
                    ->get();
        } else {
            $addition = "";
            foreach (explode(",",$this->option('methods')) as $method){
                $addition .= PHP_EOL . $this->getTemplate('route/routes-' . trim($method))
                        ->with([
                            'resource' => str_plural($resource),
                            'version' => strtoupper($version),
                            'controller' => $this->getController()
                        ])
                        ->get();
            }
        }
        $content = str_replace(
            'function(Router $router){',
            'function(Router $router){ ' . PHP_EOL . $addition ,
            $content);

        $this->save($content, $routesPath, "{$resource} routes", true);
    }

    protected function getController()
    {
        $controller = $this->option('controller');
        if(! $controller){
            $controller = ucwords(str_plural(camel_case($this->argument('resource')))) . 'Controller';
        }
        return $controller;
    }

}
