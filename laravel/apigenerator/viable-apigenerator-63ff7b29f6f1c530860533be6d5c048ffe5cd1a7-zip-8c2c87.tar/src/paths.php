<?php
return [
    'models'       => base_path('app/Models'),
    'services'     => base_path('app/Services'),
    'repositories' => base_path('app/Repositories'),
    'api'          => base_path('app/Http/Controllers/Api/Extranet/V1'),
    'traits'       => base_path('app/Traits')
];