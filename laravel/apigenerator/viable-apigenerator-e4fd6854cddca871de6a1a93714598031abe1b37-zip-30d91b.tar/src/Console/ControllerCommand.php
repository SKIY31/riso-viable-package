<?php namespace Viable\Apigenerator\Console;


class ControllerCommand extends BaseCommand {

	protected $signature = 'generate:controller
        {model : Name of the model (with namespace if not App)}
		{--no-routes= : without routes}
        {--force= : override the existing files}
        {--restversion= : Version - default V1 }
        {--methods= : methods for resource rest api.}
    ';

	protected $description = 'Generates REST Api controller using the RESTActions trait';

    public function handle()
    {
    	$model = $this->argument('model');
    	$version = ($this->option('restversion'))? $this->option('restversion'):'V1';
    	if(strrpos($model, "\\") === false){
    		$name = $model;
    		$model = "App\\Models\\" . $model;
    	} else {
    		$name = explode("\\", $model);
    		$name = $name[count($name) - 1];
    	}
        $controller = ucwords(str_plural($name)) . 'Controller';
        $content = $this->getTemplate('controller/controller')
        	->with([
        		'name' => $controller,
        		'model' => $model,
                'version'   => $version
        	])
        	->get();

        // add methods
        $methods = (! $this->option('methods'))?['all','get','add','put','remove'] :
            explode(",",$this->option('methods'));
        foreach ($methods as $method){
            $content .= PHP_EOL . $this->getTemplate('controller/controller-' . $method)
                    ->with([
                        'name' => $controller,
                        'model' => $model,
                        'version'   => $version
                    ])
                    ->get();
        }
        // add closing bracket

        $content .= PHP_EOL . "}";

        $this->save($content, "./app/Http/Controllers/{$version}/{$controller}.php", "{$controller}");

        if(! $this->option('no-routes')){
            $this->call('generate:route', [
                'resource' => snake_case($name, '-'),
                '--controller' => $controller,
                '--restversion' => $version,
                '--methods' => $this->option('methods')
            ]);
        }
    }

}
