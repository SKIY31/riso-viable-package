<?php namespace Viable\Apigenerator\Console;


class MiddlewareCommand extends BaseCommand {

	protected $signature = 'generate:middleware';

	protected $description = 'Generates REST Api middleware';

    public function handle()
    {

    }

}
