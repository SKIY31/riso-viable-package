<?php namespace Viable\Apigenerator\Template;

use Illuminate\Filesystem\Filesystem;
use Viable\Apigenerator\Exceptions\TemplateException;
use Viable\Apigenerator\Template\Template;


class TemplateLoader {
	
	protected $fs;

	protected $loaded;

	public function __construct(Filesystem $fs)
	{
		$this->fs = $fs;
		$this->loaded = [];
	}

	public function load($name)
	{
		if(! isset($this->loaded[$name])){
			$path = __DIR__ . "/../../templates/{$name}.stub";
			try {
				$this->loaded[$name] = $this->fs->get($path);
			} catch(\Exception $e) {
				throw new TemplateException("Unable to read the file '{$path}'");
			}
		}
		return new Template($this, $this->loaded[$name]);
	}

}
